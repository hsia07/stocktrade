@echo off
REM ╔═══════════════════════════════════════╗
REM ║  台股 AI 交易系統  一鍵啟動            ║
REM ║  每天執行此檔案即可，系統自動排程      ║
REM ╚═══════════════════════════════════════╝

title 台股 AI 六角色交易系統

echo.
echo  ██████  台股 AI 六角色交易系統 v2
echo  正在啟動後端引擎...
echo.

REM 切換到腳本所在資料夾
cd /d "%~dp0"

REM 檢查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [錯誤] 找不到 Python，請先安裝 Python 3.10+
    pause
    exit /b 1
)

REM 安裝依賴（首次執行）
echo  正在確認套件安裝...
pip install -q fastapi uvicorn shioaji pandas numpy python-dotenv requests schedule

REM 啟動後端
echo.
echo  ✅ 後端啟動中（WebSocket: ws://localhost:8765）
echo  ✅ 請在瀏覽器開啟 index.html
echo  ✅ Ctrl+C 可停止系統
echo.
python server.py

pause
