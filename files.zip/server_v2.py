"""
╔══════════════════════════════════════════════════════════════╗
║   台股 AI 六角色自動交易系統 v2.0                              ║
║   FastAPI + WebSocket + Shioaji + Line/Email 通知             ║
║                                                              ║
║   啟動：python server.py                                      ║
║   排程：自動在 09:00 開始交易，13:30 停止                      ║
╚══════════════════════════════════════════════════════════════╝

pip install fastapi uvicorn shioaji pandas numpy python-dotenv requests schedule
"""

import asyncio, json, logging, os, time, math, smtplib, schedule, threading
from datetime import datetime
from collections import deque
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Optional
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

import requests
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from dotenv import load_dotenv

load_dotenv()

# ══════════════════════════════════════════════════════════════
# ① 全域設定
# ══════════════════════════════════════════════════════════════
PAPER_TRADE    = os.getenv("PAPER_TRADE",   "true").lower() == "true"
TOTAL_CAPITAL  = float(os.getenv("TOTAL_CAPITAL", "500000"))
WATCH_LIST     = os.getenv("WATCH_LIST",    "2330,2454,2382,3017,2317,2308").split(",")
LINE_TOKEN     = os.getenv("LINE_TOKEN",    "")
EMAIL_FROM     = os.getenv("EMAIL_FROM",    "")
EMAIL_TO       = os.getenv("EMAIL_TO",      "")
EMAIL_PASS     = os.getenv("EMAIL_PASS",    "")
EMAIL_SMTP     = os.getenv("EMAIL_SMTP",    "smtp.gmail.com")
EMAIL_PORT     = int(os.getenv("EMAIL_PORT", "587"))
AUTO_TRADE     = os.getenv("AUTO_TRADE",    "true").lower() == "true"

SYM_NAMES = {
    "2330": "台積電", "2454": "聯發科", "2382": "廣達",
    "3017": "奇鋐",  "2317": "鴻海",  "2308": "台達電",
    "2603": "長榮",  "2881": "富邦金", "2882": "國泰金",
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("trading.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("TW-AI")


# ══════════════════════════════════════════════════════════════
# ② 通知模組（Line + Email）
# ══════════════════════════════════════════════════════════════
class Notifier:
    """統一通知介面，Line 和 Email 並發"""

    @staticmethod
    def send(subject: str, body: str, level: str = "info"):
        """level: info / warn / alert"""
        prefix = {"info": "ℹ️", "warn": "⚠️", "alert": "🚨"}.get(level, "ℹ️")
        full   = f"{prefix} {subject}\n\n{body}"
        log.info(f"[通知] {subject}")

        if LINE_TOKEN:
            Notifier._line(full[:1000])
        if EMAIL_FROM and EMAIL_TO and EMAIL_PASS:
            Notifier._email(f"{prefix} {subject}", body)

    @staticmethod
    def _line(message: str):
        try:
            requests.post(
                "https://notify-api.line.me/api/notify",
                headers={"Authorization": f"Bearer {LINE_TOKEN}"},
                data={"message": f"\n{message}"},
                timeout=8,
            )
        except Exception as e:
            log.warning(f"Line 通知失敗：{e}")

    @staticmethod
    def _email(subject: str, body: str):
        try:
            msg = MIMEMultipart()
            msg["From"]    = EMAIL_FROM
            msg["To"]      = EMAIL_TO
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain", "utf-8"))
            with smtplib.SMTP(EMAIL_SMTP, EMAIL_PORT) as s:
                s.starttls()
                s.login(EMAIL_FROM, EMAIL_PASS)
                s.send_message(msg)
        except Exception as e:
            log.warning(f"Email 通知失敗：{e}")


# ══════════════════════════════════════════════════════════════
# ③ 資料模型
# ══════════════════════════════════════════════════════════════
class Direction(str, Enum):
    LONG  = "long"
    SHORT = "short"
    NONE  = "none"

@dataclass
class Signal:
    symbol:      str
    direction:   Direction
    entry_price: float
    stop_loss:   float
    target_1:    float
    target_2:    float
    confidence:  float
    reason:      str
    timestamp:   str

@dataclass
class AgentReport:
    role:      str
    icon:      str
    status:    str      # ok | warn | alert | idle
    summary:   str
    details:   list
    timestamp: str = ""
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().strftime("%H:%M:%S")

@dataclass
class TradeRecord:
    id:         str
    symbol:     str
    direction:  str
    entry:      float
    exit:       float
    lots:       int
    pnl:        float
    reason:     str
    open_time:  str
    close_time: str

@dataclass
class BacktestResult:
    symbol:        str
    total_trades:  int
    win_rate:      float
    profit_factor: float
    avg_win:       float
    avg_loss:      float
    max_drawdown:  float
    total_pnl:     float
    equity_curve:  list   # [{idx, cum_pnl}] 給前端畫圖
    monthly_pnl:   list   # [{month, pnl}]


# ══════════════════════════════════════════════════════════════
# ④ 角色一：量化研究員
# ══════════════════════════════════════════════════════════════
class QuantResearcher:
    def __init__(self):
        self.alpha_scores = {}

    def analyze(self, symbol: str, bars: list) -> AgentReport:
        if len(bars) < 20:
            return AgentReport("量化研究員", "🔬", "idle", "資料累積中", ["等待 20 根 K 棒…"])

        closes  = [b["close"]  for b in bars]
        volumes = [b["volume"] for b in bars]
        highs   = [b["high"]   for b in bars]

        # Alpha 1：布林帶壓縮（低波動後爆發）
        ma20   = sum(closes[-20:]) / 20
        std20  = (sum((c - ma20) ** 2 for c in closes[-20:]) / 20) ** 0.5
        bb_w   = std20 * 2 / ma20 * 100
        squeeze = bb_w < 3.5

        # Alpha 2：20 日新高突破
        h20      = max(highs[-21:-1])
        breakout = closes[-1] > h20

        # Alpha 3：短期均線向上斜率
        e5_now  = sum(closes[-5:]) / 5
        e5_prev = sum(closes[-8:-3]) / 5
        slope   = (e5_now - e5_prev) / e5_prev * 100

        # Alpha 4：量價背離（爆量不漲 → 警示）
        avg_v5 = sum(volumes[-6:-1]) / 5
        vol_r  = volumes[-1] / (avg_v5 + 1)
        p_chg  = (closes[-1] - closes[-5]) / closes[-5] * 100
        diverge = vol_r > 2 and p_chg < -0.5

        score = 0
        findings = []
        if breakout:  score += 30; findings.append(f"✅ 20日新高突破 {closes[-1]:.1f} > {h20:.1f}")
        if squeeze:   score += 25; findings.append(f"⚡ 布林帶壓縮 {bb_w:.1f}%，蓄勢待發")
        if slope > 0.3: score += 20; findings.append(f"📈 短期均線上斜 +{slope:.2f}%")
        if diverge:   score -= 25; findings.append(f"⚠️ 量價背離：量增 {vol_r:.1f}x 但價跌 {p_chg:.1f}%")
        if not findings: findings.append("目前無明顯 Alpha 訊號")

        self.alpha_scores[symbol] = score
        status = "ok" if score >= 40 else "warn" if score >= 10 else "idle"
        return AgentReport("量化研究員", "🔬", status, f"{symbol} Alpha {score}/75", findings)


# ══════════════════════════════════════════════════════════════
# ⑤ 角色二：回測工程師（含完整回測資料給視覺化）
# ══════════════════════════════════════════════════════════════
class Backtester:
    def __init__(self):
        self.results: dict[str, BacktestResult] = {}

    def run(self, symbol: str, bars: list) -> tuple[AgentReport, Optional[BacktestResult]]:
        if len(bars) < 30:
            return AgentReport("回測工程師", "📊", "idle", "資料不足", ["需要 30 根 K 棒"]), None

        closes = [b["close"] for b in bars]
        trades, equity, cum = [], [], 0
        in_pos = None

        for i in range(20, len(closes)):
            w   = closes[:i+1]
            e5  = sum(w[-5:]) / 5
            e20 = sum(w[-20:]) / 20

            if in_pos is None and e5 > e20 * 1.002:
                in_pos = {"entry": closes[i], "idx": i}

            elif in_pos:
                held = i - in_pos["idx"]
                hit_stop   = closes[i] < in_pos["entry"] * 0.988   # -1.2% 停損
                hit_target = closes[i] > in_pos["entry"] * 1.022   # +2.2% 目標
                if hit_stop or hit_target or held >= 30:
                    pnl = closes[i] - in_pos["entry"]
                    cum += pnl
                    trades.append({"pnl": pnl, "reason": "stop" if hit_stop else "target" if hit_target else "timeout"})
                    equity.append({"idx": len(trades), "cum_pnl": round(cum, 2)})
                    in_pos = None

        if not trades:
            return AgentReport("回測工程師", "📊", "idle", "無交易觸發", ["條件未達"]), None

        pnl_list = [t["pnl"] for t in trades]
        wins     = [p for p in pnl_list if p > 0]
        losses   = [p for p in pnl_list if p < 0]
        wr       = len(wins) / len(trades) * 100
        pf       = abs(sum(wins) / sum(losses)) if losses else 99.0
        avg_w    = sum(wins)   / len(wins)   if wins   else 0
        avg_l    = sum(losses) / len(losses) if losses else 0

        # 最大回撤
        peak, dd, max_dd = 0, 0, 0
        run = 0
        for p in pnl_list:
            run += p
            peak   = max(peak, run)
            dd     = run - peak
            max_dd = min(max_dd, dd)

        # 月度損益（模擬，依 K 棒索引分段）
        chunk = max(len(trades) // 4, 1)
        monthly = [
            {"month": f"第{i+1}段", "pnl": round(sum(pnl_list[i*chunk:(i+1)*chunk]), 2)}
            for i in range(4)
        ]

        res = BacktestResult(
            symbol=symbol, total_trades=len(trades),
            win_rate=round(wr, 1), profit_factor=round(pf, 2),
            avg_win=round(avg_w, 2), avg_loss=round(avg_l, 2),
            max_drawdown=round(max_dd, 2), total_pnl=round(sum(pnl_list), 2),
            equity_curve=equity, monthly_pnl=monthly,
        )
        self.results[symbol] = res
        status = "ok" if wr > 55 and pf > 1.5 else "warn"

        return AgentReport(
            "回測工程師", "📊", status,
            f"{symbol} 勝率 {wr:.0f}% | 盈虧比 {pf:.1f}",
            [
                f"總交易筆數：{len(trades)}",
                f"勝率：{wr:.1f}%",
                f"盈虧比：{pf:.2f}",
                f"平均獲利：+{avg_w:.2f}  |  平均虧損：{avg_l:.2f}",
                f"最大回撤：{max_dd:.2f}",
                f"累計損益：{sum(pnl_list):+.2f}",
            ]
        ), res


# ══════════════════════════════════════════════════════════════
# ⑥ 角色三：風控官
# ══════════════════════════════════════════════════════════════
class RiskOfficer:
    # ── 風控參數（可透過 .env 覆蓋）──
    MAX_DAILY_LOSS   = float(os.getenv("MAX_DAILY_LOSS",  "5000"))
    MAX_SINGLE_LOSS  = float(os.getenv("MAX_SINGLE_LOSS", "1500"))
    MAX_TRADES       = int(os.getenv("MAX_TRADES",        "6"))
    MAX_POSITIONS    = int(os.getenv("MAX_POSITIONS",     "2"))
    MAX_CONSEC_LOSS  = int(os.getenv("MAX_CONSEC_LOSS",   "3"))
    MIN_CONFIDENCE   = float(os.getenv("MIN_CONFIDENCE",  "65"))
    TRADE_START      = os.getenv("TRADE_START",  "09:10")
    TRADE_END        = os.getenv("TRADE_END",    "13:00")
    FORCE_CLOSE      = os.getenv("FORCE_CLOSE",  "13:20")
    MAX_CHASE_PCT    = float(os.getenv("MAX_CHASE_PCT",   "0.005"))

    def __init__(self):
        self.daily_pnl        = 0.0
        self.daily_trades     = 0
        self.consecutive_loss = 0
        self.open_positions: dict = {}
        self.is_halted        = False
        self.halt_reason      = ""

    def reset_daily(self):
        self.daily_pnl, self.daily_trades = 0.0, 0
        self.consecutive_loss = 0
        self.open_positions   = {}
        self.is_halted        = False
        self.halt_reason      = ""
        Notifier.send("風控重置", "每日風控統計已重置，交易系統開始運行", "info")

    def can_enter(self, signal: Signal, price: float) -> tuple[bool, str]:
        now = datetime.now().strftime("%H:%M")
        checks = [
            (not self.is_halted,                           f"系統停機：{self.halt_reason}"),
            (self.TRADE_START <= now <= self.TRADE_END,    f"非交易時段 {self.TRADE_START}~{self.TRADE_END}"),
            (self.daily_trades < self.MAX_TRADES,          f"已達單日 {self.MAX_TRADES} 筆"),
            (self.daily_pnl > -self.MAX_DAILY_LOSS,        f"達單日虧損上限 -{self.MAX_DAILY_LOSS}"),
            (len(self.open_positions) < self.MAX_POSITIONS,f"已有 {self.MAX_POSITIONS} 持倉"),
            (signal.symbol not in self.open_positions,     f"{signal.symbol} 已有持倉"),
            (signal.confidence >= self.MIN_CONFIDENCE,     f"信心度 {signal.confidence:.0f} < {self.MIN_CONFIDENCE}"),
            (self.consecutive_loss < self.MAX_CONSEC_LOSS, f"連敗 {self.consecutive_loss} 次"),
            (abs(price - signal.entry_price) / signal.entry_price < self.MAX_CHASE_PCT, "追價超過限制"),
        ]
        for ok, reason in checks:
            if not ok:
                return False, reason
        return True, "OK"

    def calc_lots(self, signal: Signal, price: float) -> int:
        risk = abs(price - signal.stop_loss)
        if risk <= 0:
            return 0
        by_loss    = int(self.MAX_SINGLE_LOSS / risk)
        by_capital = int(TOTAL_CAPITAL * 0.25 / (price * 1000))
        return max(min(by_loss, by_capital, 3), 0)

    def on_entry(self, signal: Signal, lots: int, price: float):
        self.daily_trades += 1
        self.open_positions[signal.symbol] = {
            "direction": signal.direction, "entry": price,
            "lots": lots, "stop": signal.stop_loss,
            "t1": signal.target_1, "t2": signal.target_2,
            "partial": False,
        }

    def on_exit(self, symbol: str, pnl: float):
        self.daily_pnl += pnl
        self.open_positions.pop(symbol, None)
        if pnl < 0:
            self.consecutive_loss += 1
            if self.consecutive_loss >= self.MAX_CONSEC_LOSS:
                self.is_halted   = True
                self.halt_reason = f"連敗 {self.consecutive_loss} 次"
                Notifier.send("風控停機", f"已連續虧損 {self.consecutive_loss} 次，系統自動暫停交易\n今日損益：NT$ {self.daily_pnl:+.0f}", "alert")
        else:
            self.consecutive_loss = 0

    def get_report(self) -> AgentReport:
        remain = self.MAX_DAILY_LOSS + self.daily_pnl
        status = "alert" if self.is_halted else "warn" if remain < 1500 else "ok"
        return AgentReport("風控官", "🛡️", status, f"剩餘虧損額度 NT${remain:.0f}", [
            f"今日損益：NT$ {self.daily_pnl:+.0f}",
            f"剩餘虧損額度：NT$ {remain:.0f}",
            f"剩餘交易次數：{self.MAX_TRADES - self.daily_trades}",
            f"當前持倉：{len(self.open_positions)} / {self.MAX_POSITIONS}",
            f"連敗次數：{self.consecutive_loss} / {self.MAX_CONSEC_LOSS}",
            f"{'🔴 停機：' + self.halt_reason if self.is_halted else '🟢 正常運行'}",
        ])


# ══════════════════════════════════════════════════════════════
# ⑦ 角色四：信號工程師
# ══════════════════════════════════════════════════════════════
class SignalEngineer:
    def __init__(self):
        self._vwap: dict = {}
        self._signal_history: list = []

    def reset_vwap(self, symbol: str):
        self._vwap[symbol] = {"pv": 0.0, "vol": 0}

    def update_vwap(self, symbol: str, bar: dict):
        d = self._vwap.setdefault(symbol, {"pv": 0.0, "vol": 0})
        mid = (bar["high"] + bar["low"] + bar["close"]) / 3
        d["pv"]  += mid * bar["volume"]
        d["vol"] += bar["volume"]

    def vwap(self, symbol: str) -> float:
        d = self._vwap.get(symbol, {})
        return d["pv"] / d["vol"] if d.get("vol") else 0

    @staticmethod
    def _ema(closes: list, span: int) -> float:
        k, e = 2 / (span + 1), closes[0]
        for c in closes[1:]:
            e = c * k + e * (1 - k)
        return e

    @staticmethod
    def _rsi(closes: list, n: int = 14) -> float:
        if len(closes) < n + 1:
            return 50
        d = [closes[i] - closes[i-1] for i in range(1, len(closes))]
        ag = sum(max(x, 0) for x in d[-n:]) / n
        al = sum(-min(x, 0) for x in d[-n:]) / n
        return 100 if al == 0 else 100 - 100 / (1 + ag / al)

    @staticmethod
    def _atr(bars: list, n: int = 14) -> float:
        trs = [max(b["high"] - b["low"],
                   abs(b["high"] - bars[i-1]["close"]),
                   abs(b["low"]  - bars[i-1]["close"])) for i, b in enumerate(bars) if i > 0]
        return sum(trs[-n:]) / min(len(trs), n) if trs else 1

    def evaluate(self, symbol: str, bars: list, tick: dict, order_book: dict) -> tuple[Optional[Signal], AgentReport]:
        if len(bars) < 20:
            return None, AgentReport("信號工程師", "⚡", "idle", "資料累積中", ["等待 20 根 K 棒…"])

        closes = [b["close"] for b in bars]
        price  = tick.get("price", closes[-1])
        vwap   = self.vwap(symbol)
        ema5   = self._ema(closes[-10:], 5)
        ema20  = self._ema(closes[-25:], 20)
        rsi    = self._rsi(closes)
        atr    = self._atr(bars)
        vol_r  = bars[-1]["volume"] / (sum(b["volume"] for b in bars[-6:-1]) / 5 + 1)
        bid_v  = order_book.get("bid_vol", 100)
        ask_v  = order_book.get("ask_vol", 100)

        lc = dict(above_vwap=price>vwap, ema_bull=ema5>ema20, rsi_ok=45<=rsi<=70, vol=vol_r>=1.5, bid_dom=bid_v>ask_v*1.4)
        sc = dict(below_vwap=price<vwap, ema_bear=ema5<ema20, rsi_ok=30<=rsi<=55, vol=vol_r>=1.5, ask_dom=ask_v>bid_v*1.4)
        ls, ss = sum(lc.values()), sum(sc.values())
        bonus  = (10 if vol_r > 2.5 else 0) + (8 if rsi > 65 and ls == 5 else 0) + (8 if rsi < 35 and ss == 5 else 0)

        lines = [
            f"VWAP {vwap:.2f} | 現價 {price:.2f}",
            f"EMA5 {ema5:.2f} | EMA20 {ema20:.2f}",
            f"RSI {rsi:.1f} | ATR {atr:.2f}",
            f"量比 {vol_r:.2f}x | 委買量 {bid_v} / 委賣量 {ask_v}",
            f"多頭條件 {ls}/5 | 空頭條件 {ss}/5",
        ]
        signal = None

        if ls == 5:
            conf   = min(60 + bonus, 95)
            signal = Signal(symbol, Direction.LONG, price,
                            round(price - atr*1.2, 2), round(price + atr*1.5, 2), round(price + atr*2.8, 2),
                            conf, "多頭全條件", datetime.now().strftime("%H:%M:%S"))
            lines.append(f"🟢 多頭信號 信心度 {conf:.0f}% | 止損 {signal.stop_loss} | 目標 {signal.target_1}/{signal.target_2}")
            rep = AgentReport("信號工程師", "⚡", "ok", f"🟢 {symbol} 多頭 {conf:.0f}%", lines)
            self._signal_history.append(asdict(signal))

        elif ss == 5:
            conf   = min(60 + bonus, 95)
            signal = Signal(symbol, Direction.SHORT, price,
                            round(price + atr*1.2, 2), round(price - atr*1.5, 2), round(price - atr*2.8, 2),
                            conf, "空頭全條件", datetime.now().strftime("%H:%M:%S"))
            lines.append(f"🔴 空頭信號 信心度 {conf:.0f}% | 止損 {signal.stop_loss} | 目標 {signal.target_1}/{signal.target_2}")
            rep = AgentReport("信號工程師", "⚡", "alert", f"🔴 {symbol} 空頭 {conf:.0f}%", lines)
            self._signal_history.append(asdict(signal))

        else:
            rep = AgentReport("信號工程師", "⚡", "idle", f"{symbol} 觀望中（多{ls}/空{ss}）", lines)

        return signal, rep

    def get_history(self) -> list:
        return self._signal_history[-50:]


# ══════════════════════════════════════════════════════════════
# ⑧ 角色五：執行工程師
# ══════════════════════════════════════════════════════════════
class ExecutionEngineer:
    def __init__(self):
        self.orders: list = []
        self._api         = None

    def set_api(self, api):
        self._api = api

    def place(self, symbol: str, action: str, lots: int, price: float, reason: str) -> dict:
        oid = f"{'P' if PAPER_TRADE else 'R'}-{symbol}-{int(time.time())}"
        rec = dict(id=oid, symbol=symbol, action=action, lots=lots,
                   price=price, reason=reason,
                   status="simulated" if PAPER_TRADE else "sent",
                   time=datetime.now().strftime("%H:%M:%S"))
        self.orders.append(rec)
        log.info(f"{'📝[模擬]' if PAPER_TRADE else '✅[真實]'} {action} {symbol} {lots}張 @{price} | {reason}")

        if not PAPER_TRADE and self._api:
            try:
                import shioaji as sj
                from shioaji import constant
                contract = self._api.Contracts.Stocks[symbol]
                act = constant.Action.Buy if action == "Buy" else constant.Action.Sell
                order = self._api.Order(
                    price=price, quantity=lots, action=act,
                    price_type=constant.StockPriceType.LMT,
                    order_type=constant.OrderType.ROD,
                    order_lot=constant.StockOrderLot.Common,
                    account=self._api.stock_account,
                )
                trade = self._api.place_order(contract, order)
                rec["status"] = "placed"
                rec["broker_id"] = trade.order.id
            except Exception as e:
                rec["status"] = "error"
                rec["error"]  = str(e)
                Notifier.send("下單失敗", f"{symbol} {action} {lots}張\n錯誤：{e}", "alert")

        return rec

    def get_report(self) -> AgentReport:
        today  = [o for o in self.orders if o["time"] >= "09:00"]
        errors = [o for o in today if o.get("status") == "error"]
        status = "alert" if errors else "ok" if today else "idle"
        details = ([f"今日委託：{len(today)} 筆"] +
                   [f"{'❌' if o.get('status')=='error' else '✅'} {o['action']} {o['symbol']} {o['lots']}張 @{o['price']} {o['time']}"
                    for o in today[-6:]])
        return AgentReport("執行工程師", "⚙️", status, f"今日委託 {len(today)} 筆", details)


# ══════════════════════════════════════════════════════════════
# ⑨ 角色六：市場分析師
# ══════════════════════════════════════════════════════════════
class MarketAnalyst:
    def __init__(self):
        self.anomalies: list = []

    def analyze(self, symbol: str, bars: list, tick: dict) -> AgentReport:
        if len(bars) < 5:
            return AgentReport("市場分析師", "🔭", "idle", "等待行情", ["等待 Tick…"])

        closes  = [b["close"]  for b in bars]
        volumes = [b["volume"] for b in bars]
        price   = tick.get("price", closes[-1])
        found   = []

        # 單棒異常
        if len(closes) >= 2:
            chg = (closes[-1] - closes[-2]) / closes[-2] * 100
            if abs(chg) > 2:
                found.append(f"⚡ 單棒異常 {chg:+.1f}%")
                self.anomalies.append({"symbol": symbol, "type": "spike", "val": chg,
                                       "time": datetime.now().strftime("%H:%M:%S")})
                if abs(chg) > 4:
                    Notifier.send(f"異常波動 {symbol}", f"單棒漲跌 {chg:+.1f}%，請注意風險", "warn")

        # 爆量
        avg_v = sum(volumes[-6:-1]) / 5 if len(volumes) >= 6 else volumes[-1]
        vr    = volumes[-1] / (avg_v + 1)
        if vr > 3:
            found.append(f"💥 爆量 {vr:.1f}x")

        # 連續同色
        if len(bars) >= 6:
            if all(bars[-i-1]["close"] > bars[-i-1]["open"] for i in range(5)):
                found.append("📈 連續 5 紅棒，短線過熱")
            elif all(bars[-i-1]["close"] < bars[-i-1]["open"] for i in range(5)):
                found.append("📉 連續 5 綠棒，賣壓沉重")

        day_chg = (price - closes[0]) / closes[0] * 100
        if not found:
            found.append(f"行情正常，今日 {day_chg:+.1f}%")
        found.insert(0, f"現價：{price:.2f}  今日 {day_chg:+.1f}%")

        status = "warn" if any(k in " ".join(found) for k in ["異常","爆量","過熱","沉重"]) else "ok"
        return AgentReport("市場分析師", "🔭", status, f"{symbol} 今日 {day_chg:+.1f}%", found)


# ══════════════════════════════════════════════════════════════
# ⑩ 模擬行情引擎（無 Shioaji 帳號時使用）
# ══════════════════════════════════════════════════════════════
class MockDataEngine:
    BASES = {"2330":866,"2454":1265,"2382":267,"3017":588,"2317":154,"2308":342}

    def __init__(self):
        self.prices  = dict(self.BASES)
        self.t       = 0
        self.bars:   dict[str, deque] = {s: deque(maxlen=120) for s in WATCH_LIST}
        self._buf:   dict[str, list]  = {s: [] for s in WATCH_LIST}
        self._cmin:  dict[str, str]   = {}

    def _rnd(self, seed: int) -> float:
        return ((seed * 1664525 + 1013904223) & 0xFFFFFFFF) / 0xFFFFFFFF

    def tick(self) -> dict:
        self.t += 1
        out = {}
        for sym in WATCH_LIST:
            base  = self.prices.get(sym, 100)
            noise = (self._rnd(self.t * 7 + hash(sym) % 997) - 0.5) * 0.004
            trend = math.sin(self.t / 30) * 0.001
            price = round(base * (1 + noise + trend), 2)
            self.prices[sym] = price
            vol   = int(200 + self._rnd(self.t + hash(sym)) * 800)
            bid_v = int(50 + self._rnd(self.t * 3 + hash(sym)) * 200)
            ask_v = int(50 + self._rnd(self.t * 5 + hash(sym)) * 200)
            out[sym] = {"price": price, "volume": vol,
                        "bid": round(price - 0.5, 2), "ask": round(price + 0.5, 2),
                        "bid_vol": bid_v, "ask_vol": ask_v}

            # K 棒收合
            now_m = datetime.now().strftime("%H:%M")
            if self._cmin.get(sym) and self._cmin[sym] != now_m:
                buf = self._buf[sym]
                if buf:
                    ps = [t["price"] for t in buf]
                    self.bars[sym].append({
                        "time": self._cmin[sym], "open": ps[0],
                        "high": max(ps), "low": min(ps), "close": ps[-1],
                        "volume": sum(t["volume"] for t in buf),
                    })
                self._buf[sym] = []
            self._cmin[sym] = now_m
            self._buf[sym].append(out[sym])
        return out


# ══════════════════════════════════════════════════════════════
# ⑪ 主交易引擎
# ══════════════════════════════════════════════════════════════
class TradingEngine:
    def __init__(self):
        self.quant      = QuantResearcher()
        self.backtester = Backtester()
        self.risk       = RiskOfficer()
        self.signal_eng = SignalEngineer()
        self.execution  = ExecutionEngineer()
        self.analyst    = MarketAnalyst()
        self.mock       = MockDataEngine()

        self.latest_ticks:   dict = {}
        self.agent_reports:  dict = {}
        self.backtest_cache: dict = {}
        self.trades_log:     list[TradeRecord] = []
        self._api                 = None
        self._running             = False
        self._trading_active      = False   # 只在盤中時間交易

    # ── Shioaji 連線 ──
    def connect_shioaji(self):
        if PAPER_TRADE:
            log.info("📝 紙交易模式")
            return
        try:
            import shioaji as sj
            api = sj.Shioaji()
            api.login(api_key=os.getenv("SHIOAJI_API_KEY",""),
                      secret_key=os.getenv("SHIOAJI_SECRET_KEY",""),
                      fetch_contract=True)
            api.activate_ca(ca_path=os.getenv("SHIOAJI_CERT_PATH",""),
                            ca_passwd=os.getenv("SHIOAJI_CERT_PASS",""),
                            person_id=os.getenv("SHIOAJI_ACCOUNT_ID",""))
            self._api = api
            self.execution.set_api(api)
            log.info("✅ Shioaji 連線成功")
            Notifier.send("系統啟動", "Shioaji 連線成功，交易引擎就緒", "info")
        except Exception as e:
            log.warning(f"Shioaji 失敗，使用模擬資料：{e}")

    # ── 主迴圈 ──
    async def run_loop(self):
        self._running = True
        log.info("🚀 交易引擎主迴圈啟動")
        bt_counter = 0

        while self._running:
            ticks = self.mock.tick()
            self.latest_ticks = ticks
            now_s = datetime.now().strftime("%H:%M")
            self._trading_active = AUTO_TRADE and "09:00" <= now_s <= "13:30"

            for sym in WATCH_LIST:
                tick  = ticks[sym]
                bars  = list(self.mock.bars[sym])
                if bars:
                    self.signal_eng.update_vwap(sym, bars[-1])

                obook = {"bid_vol": tick["bid_vol"], "ask_vol": tick["ask_vol"]}

                # 六角色分析
                self.agent_reports[f"quant_{sym}"]    = asdict(self.quant.analyze(sym, bars))
                self.agent_reports[f"market_{sym}"]   = asdict(self.analyst.analyze(sym, bars, tick))
                sig, sig_rep = self.signal_eng.evaluate(sym, bars, tick, obook)
                self.agent_reports[f"signal_{sym}"]   = asdict(sig_rep)

                # 每 20 個 tick 跑一次回測（避免過度計算）
                if bt_counter % 20 == 0 and bars:
                    bt_rep, bt_res = self.backtester.run(sym, bars)
                    self.agent_reports[f"backtest_{sym}"] = asdict(bt_rep)
                    if bt_res:
                        self.backtest_cache[sym] = asdict(bt_res)

                # 信號 → 風控 → 下單
                if sig and self._trading_active:
                    ok, reason = self.risk.can_enter(sig, tick["price"])
                    if ok:
                        lots = self.risk.calc_lots(sig, tick["price"])
                        if lots > 0:
                            act = "Buy" if sig.direction == Direction.LONG else "Sell"
                            self.execution.place(sym, act, lots, tick["price"], sig.reason)
                            self.risk.on_entry(sig, lots, tick["price"])
                            Notifier.send(
                                f"進場信號 {sym}",
                                f"方向：{'多頭' if sig.direction==Direction.LONG else '空頭'}\n"
                                f"進場：{tick['price']} | 止損：{sig.stop_loss}\n"
                                f"目標：{sig.target_1} / {sig.target_2}\n"
                                f"信心度：{sig.confidence:.0f}% | 張數：{lots}",
                                "info",
                            )
                    else:
                        log.info(f"⛔ 風控攔截 {sym}：{reason}")

                # 持倉管理
                self._manage_positions(sym, tick["price"])

            # 公用 agent 報告
            self.agent_reports["risk"]      = asdict(self.risk.get_report())
            self.agent_reports["execution"] = asdict(self.execution.get_report())
            bt_counter += 1
            await asyncio.sleep(3)

    # ── 持倉管理 ──
    def _manage_positions(self, symbol: str, price: float):
        pos = self.risk.open_positions.get(symbol)
        if not pos:
            return
        now   = datetime.now().strftime("%H:%M")
        mult  = 1 if pos["direction"] == Direction.LONG else -1
        act   = "Sell" if pos["direction"] == Direction.LONG else "Buy"

        def close(reason: str):
            entry = pos["entry"]
            pnl   = (price - entry) * mult * pos["lots"] * 1000 * 0.9985
            self.execution.place(symbol, act, pos["lots"], price, reason)
            self.risk.on_exit(symbol, pnl)
            self.trades_log.append(TradeRecord(
                id=f"T{int(time.time())}", symbol=symbol,
                direction=str(pos["direction"]), entry=entry, exit=price,
                lots=pos["lots"], pnl=round(pnl, 0), reason=reason,
                open_time="", close_time=now,
            ))
            Notifier.send(
                f"出場 {symbol}",
                f"原因：{reason}\n進場：{entry:.2f} → 出場：{price:.2f}\n"
                f"損益：NT$ {pnl:+.0f}（今日累計 NT$ {self.risk.daily_pnl:+.0f}）",
                "ok" if pnl >= 0 else "warn",
            )

        if now >= self.risk.FORCE_CLOSE:      close("強制平倉"); return
        if mult * (price - pos["stop"]) < 0:  close("停損");     return
        if mult * (price - pos["t2"]) > 0:    close("目標獲利"); return
        if mult * (price - pos["t1"]) > 0 and not pos["partial"]:
            half = max(1, pos["lots"] // 2)
            self.execution.place(symbol, act, half, price, "部分獲利")
            pos["lots"] -= half
            pos["partial"] = True

    # ── 狀態快照 ──
    def get_state(self) -> dict:
        return {
            "ticks":          self.latest_ticks,
            "agents":         self.agent_reports,
            "positions":      self.risk.open_positions,
            "daily_pnl":      self.risk.daily_pnl,
            "daily_trades":   self.risk.daily_trades,
            "is_halted":      self.risk.is_halted,
            "halt_reason":    self.risk.halt_reason,
            "trading_active": self._trading_active,
            "trades_log":     [asdict(t) for t in self.trades_log[-30:]],
            "backtest":       self.backtest_cache,
            "signal_history": self.signal_eng.get_history(),
            "anomalies":      self.analyst.anomalies[-20:],
            "timestamp":      datetime.now().strftime("%H:%M:%S"),
        }


# ══════════════════════════════════════════════════════════════
# ⑫ 排程：每天自動重置
# ══════════════════════════════════════════════════════════════
engine = TradingEngine()

def daily_open():
    """09:00 自動執行：重置風控、重置 VWAP、發通知"""
    log.info("🌅 每日開盤重置")
    engine.risk.reset_daily()
    for sym in WATCH_LIST:
        engine.signal_eng.reset_vwap(sym)

def daily_close():
    """13:30 自動執行：強制平倉、發收盤報告"""
    log.info("🌇 收盤強制平倉")
    for sym, pos in list(engine.risk.open_positions.items()):
        tick = engine.latest_ticks.get(sym)
        if tick:
            act = "Sell" if pos["direction"] == Direction.LONG else "Buy"
            engine._manage_positions(sym, tick["price"])
    Notifier.send(
        "每日交收報告",
        f"今日損益：NT$ {engine.risk.daily_pnl:+.0f}\n"
        f"交易次數：{engine.risk.daily_trades}\n"
        f"系統狀態：{'停機' if engine.risk.is_halted else '正常'}",
        "info",
    )

def _schedule_thread():
    schedule.every().day.at("09:00").do(daily_open)
    schedule.every().day.at("13:30").do(daily_close)
    while True:
        schedule.run_pending()
        time.sleep(30)

threading.Thread(target=_schedule_thread, daemon=True).start()


# ══════════════════════════════════════════════════════════════
# ⑬ FastAPI
# ══════════════════════════════════════════════════════════════
app = FastAPI(title="台股 AI 六角色交易系統")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

clients: list[WebSocket] = []

@app.on_event("startup")
async def startup():
    engine.connect_shioaji()
    asyncio.create_task(engine.run_loop())
    asyncio.create_task(_broadcast_loop())
    log.info("🚀 FastAPI 啟動完成，WebSocket 埠 8765")

async def _broadcast_loop():
    while True:
        if clients:
            state = engine.get_state()
            msg   = json.dumps(state, ensure_ascii=False, default=str)
            dead  = []
            for ws in clients:
                try:
                    await ws.send_text(msg)
                except:
                    dead.append(ws)
            for ws in dead:
                clients.remove(ws)
        await asyncio.sleep(3)

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    clients.append(ws)
    log.info(f"🔌 前端連線，共 {len(clients)} 個")
    # 立刻推送當前狀態
    await ws.send_text(json.dumps(engine.get_state(), ensure_ascii=False, default=str))
    try:
        while True:
            raw = await ws.receive_text()
            cmd = json.loads(raw)
            if cmd.get("cmd") == "reset":
                daily_open()
            elif cmd.get("cmd") == "force_close":
                daily_close()
            elif cmd.get("cmd") == "notify_test":
                Notifier.send("測試通知", "Line/Email 通知測試成功 ✅", "info")
    except WebSocketDisconnect:
        clients.remove(ws)

# REST API（給外部呼叫或除錯用）
@app.get("/api/state")
def api_state():
    return engine.get_state()

@app.get("/api/backtest/{symbol}")
def api_backtest(symbol: str):
    return engine.backtest_cache.get(symbol, {"error": "尚無回測資料"})

@app.get("/api/trades")
def api_trades():
    return [asdict(t) for t in engine.trades_log]

@app.get("/api/signals")
def api_signals():
    return engine.signal_eng.get_history()

@app.get("/api/health")
def api_health():
    return {
        "ok": True,
        "paper_trade": PAPER_TRADE,
        "trading_active": engine._trading_active,
        "clients": len(clients),
        "time": datetime.now().strftime("%H:%M:%S"),
    }


if __name__ == "__main__":
    print("=" * 60)
    print("  台股 AI 六角色自動交易系統 v2.0")
    print(f"  模式：{'📝 紙交易' if PAPER_TRADE else '💰 真實交易'}")
    print(f"  監控：{', '.join(WATCH_LIST)}")
    print(f"  自動排程：{'✅ 開啟' if AUTO_TRADE else '❌ 關閉'}")
    print(f"  Line 通知：{'✅' if LINE_TOKEN else '❌ 未設定'}")
    print(f"  Email 通知：{'✅' if EMAIL_FROM else '❌ 未設定'}")
    print("  前端：直接開啟 index.html")
    print("=" * 60)
    uvicorn.run("server:app", host="0.0.0.0", port=8765, reload=False)
